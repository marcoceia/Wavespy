# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 16:14:22 2020

@author: marco
"""

#Python codes for analyzing Picoscope data for Rock Physics
#WavesPY Waveform Processing
#Contact: Prof. Marco Ceia (UENF/CCT/LENEP) - marco@lenep.uenf.br
#Version 1.c (July/2020)
#MIR - UENF

#Usage: type in IPython console : run WavesPy.py
#  This code aims to perform the following processing tasks to the data:
#    1-Read the psdata data file and Export picoscope in csv format.
#    2-Set start time for analysis. This action aims to remove the negative time values and initial trigger impulse 
#    3-Spectral Analysis of original data
#    4-Filter the waveform
#    5-Compare filtered and unfiltered waveforms (Time and Freq domain)
#    6-Export data in a csv format.
#    7-Time Picking for velocity estimation

#Developed in the configuration described bellow
#    Software :Anaconda 1.9.7 - Python 3.7.3 (64-bits) - Spyder 3.3.3
#Requirements 
#    Also requires: Picoscope software (Tested with version 6.14.16.5008)
#    Add-ons (Libraries): Numpy,Scipy, OS and Pandas

#In IPython console
# %reset to clear all variables
# clear to clear window

#Version control
# V1.1 - First launch
# V1.2 - Inclusion of semi-colon and comma delimiter options for reading CSV files
#      - Inclusion of Box-Car Gain. Saving this type of filtered signal is also available

#Intro message
print('################################################################')
print('  Python codes for analyzing Picoscope data for Rock Physics    ')
print('----------WavesPY - Python Waveform Analysis--------------------')
print('--------------------UENF/CCT/LENEP------------------------------')
print('   ')
print('Contact: Prof. Marco Ceia  - marco@lenep.uenf.br' )
print('################################################################')
      
# Reading an psdata file using Python 

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
from scipy import fftpack
import os
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter.filedialog import askopenfilename
from tkinter.simpledialog import askfloat
from datetime import datetime
from dragline import draggable_lines
from matplotlib.widgets import Slider


#Congiguration parameters
global t1,fts,fts2,wtype,hgraph,vgraph,ticksize
t1=1.5 #t1=0 skip just the negative time, i.e., before the initial trigger. Try t1>0 for also skiping the trigger impulse
fts=18 #Plot Fontsize used in label and, titles
fts2=12 #Plot Fontsize used in label and, titles
wtype='boxcar' #Window type
hgraph=12 #Single Graphic Length
vgraph=6  #Single Graphic Height
ticksize=14 #Tick label fontsize
plt.rcParams["axes.linewidth"] = 2
#plt.rcParams['backend'] = 'TkAgg'


#-----------------------------------------------------------------------------
#Conversion function from psdata to csv
#This function call an external program (Picoscope), which must be installed in the PC
def convert_pico_file(filename, fmt='csv'):
    command = 'picoscope /c "{}" /f {} /q /b all'.format(filename, fmt)
    res = os.system(command)
    # 0 means it ran OK
    return res == 0

#-----------------------------------------------------------------------------
def fix_filename(filename):
    if filename.endswith(".psdata"):
        return filename
    elif "." not in filename:
        return filename + ".psdata"
    else:
        # in this case filename is not valid
        return None

#-----------------------------------------------------------------------------   
#Accessing psdata file name and conversion to csv
def OpenFile():
    name = askopenfilename(initialdir=idir,
                           filetypes =(("Picoscope Files", "*.psdata"),("All Files","*.*")),
                           title = "Choose a file."
                           )
    if not name:
        return
    
    global iname, icontrol
    iname=name
    print ('Waveform Filename : '+iname)
    #Testing if extension of the file is OK. Display a msg error if not
    filename = fix_filename(iname) 

    #Converting from picoscope format to csv. Picoscope software must be previously installed in the computer
    #Access https://www.picotech.com/downloads for obtaining the software
    #Tested with Picoscope version 6.14.16.5008
    res = convert_pico_file(filename)    
    csvfilename = filename.replace(".psdata", ".csv")
    icontrol=0
    print('1 - File converted to csv using Picoscope: '+csvfilename)
    return

#-----------------------------------------------------------------------------   
def opencsv():    
    #Read signal file (*.csv) - Semicolon (;) delimited
    global csvname,outfnamehead,loc,samplid,logfile,logfname
    csvname = askopenfilename(initialdir=idir,
                           filetypes =(("CSV Files", "*.csv"),("All Files","*.*")),
                           title = "Choose a file."
                           )
    if not csvname:
        return
    
    global wavef, wavef2,wavef3,x,y,csvfile,Time_units,ChannelA_units,lfile,tmax,tmin,nsamp
    csvfile=pd.read_csv(csvname, delimiter=';') #Read whole csv file for getting the units
    Time_units=csvfile.Time[0] #Time Units
    ChannelA_units=csvfile['Channel A'][0] #Amplitude Units
    lfile=len(csvfile) #Length of Input file
    wavef=pd.read_csv(csvname, delimiter=';',skiprows=[1]) #Read csv file but skipping the unit row
    tmax=wavef.Time.max()
    tmin=wavef.Time.min()
    outfnamehead=csvname[0:(len(csvname)-4)]
    loc=csvname
#    lidir=len(idir) #Length of input folder
#    lloc=len(loc)   #Length of input file
#    samplid=loc[(lidir+1):(lloc-4)]
    ffname=os.path.basename(csvname) #Obtaining the file name
    extsep=np.char.find(ffname,'.') #Obtaining the position of the dot separator from the extension
    samplid=ffname[0:extsep] #Excluding the extension from the filename.
    print('2 - csv file read OK')
#    icontrol=1
    wavef2=wavef.where(wavef['Time'] > t1) #Samples lower than t1 will be read as Nan's
    nsamp=len(wavef2) #Length of the waveform after setting t1
    print('3 - csv file trimmed OK')
    
    
    #Filtering out Nan's
    wavef3=wavef2.dropna(subset=['Time']) #Filtering out Nan's
    print('4 - Filtered out Nan values - OK')
    x=wavef3['Time']#Unit labels
    if ChannelA_units == '(V)':
        y=wavef3['Channel A'] #If Amplitude is in V
        print('5 - Amp units in V - OK')
    elif ChannelA_units == '(mV)':
       y=wavef3['Channel A']*1e-3 #If Amplitude is in mV
       print('5 - Amp units corrected from mV to V - OK')
    else:
        print('Channel A unit unknown')
 
    #Print Waveform info on terminal screen
    print('----------------')
    print('Input filename                      : '+loc)
    print('Rock Sample ID                      : '+samplid)
    print("Number of samples (unfilt waveform) : %8.0f" % (nsamp))
    print('Selection Initial time - t1 (microsec): '+str(t1))
    print('----------------')
    print('Waveform Statistics')
    print(' ')
    print('Unfiltered')
    print("Max Amp : %8.4f" % (np.max(y)))
    print("Min Amp : %8.4f" % (np.min(y)))
    print("Mean Amp : %8.4f" % (np.mean(y)))
    
    #Print Waveform Info to a Report log file
    logfname=outfnamehead+'.log'
    logfile=open(logfname,'a+')
    print('################',file=logfile)
    print('Python codes for analyzing Picoscope data for Rock Physics',file=logfile)
    print('Single Waveform Processing',file=logfile)
    print('Author: Prof. Marco Ceia (UENF/CCT/LENEP) - marco@lenep.uenf.br',file=logfile)
    print(' ',file=logfile)
    print('LOG REPORT',file=logfile)
    print('----------------',file=logfile)
    now = datetime.now()
    print("Date and Time =", now,file=logfile)
    print('Input filename                      : '+loc,file=logfile)
    print('Rock Sample ID                      : '+samplid,file=logfile)
    print("Number of samples (unfilt waveform) : %8.0f" % (nsamp),file=logfile)
    print('Selection Initial time - t1 (microsec): '+str(t1),file=logfile)
    print('----------------',file=logfile)
    print('Waveform Statistics',file=logfile)
    print(' ',file=logfile)
    print('Unfiltered',file=logfile)
    print('Amp Units : '+ChannelA_units,file=logfile)
    print("Max Amp  : %8.4f" % (np.max(y)),file=logfile)
    print("Min Amp  : %8.4f" % (np.min(y)),file=logfile)
    print("Mean Amp : %8.4f" % (np.mean(y)),file=logfile)
    logfile.close()
    return wavef,wavef2,wavef3,x,y,Time_units,ChannelA_units,lfile,tmax,tmin,nsamp

#-----------------------------------------------------------------------------   
def opencsv2():    
    #Read signal file (*.csv)- Comma (,) delimited
    global csvname,outfnamehead,loc,samplid,logfile,logfname
    csvname = askopenfilename(initialdir=idir,
                           filetypes =(("CSV Files", "*.csv"),("All Files","*.*")),
                           title = "Choose a file."
                           )
    if not csvname:
        return
    
    global wavef, wavef2,wavef3,x,y,csvfile,Time_units,ChannelA_units,lfile,tmax,tmin,nsamp
    csvfile=pd.read_csv(csvname, delimiter=',') #Read whole csv file for getting the units
    Time_units=csvfile.Time[0] #Time Units
    ChannelA_units=csvfile['Channel A'][0] #Amplitude Units
    lfile=len(csvfile) #Length of Input file
    wavef=pd.read_csv(csvname, delimiter=',',skiprows=[1]) #Read csv file but skipping the unit row
    tmax=wavef.Time.max()
    tmin=wavef.Time.min()
    outfnamehead=csvname[0:(len(csvname)-4)]
    loc=csvname
#    lidir=len(idir) #Length of input folder
#    lloc=len(loc)   #Length of input file
#    samplid=loc[(lidir+1):(lloc-4)]
    ffname=os.path.basename(csvname) #Obtaining the file name
    extsep=np.char.find(ffname,'.') #Obtaining the position of the dot separator from the extension
    samplid=ffname[0:extsep] #Excluding the extension from the filename.
    print('2 - csv file read OK')
#    icontrol=1
    wavef2=wavef.where(wavef['Time'] > t1) #Samples lower than t1 will be read as Nan's
    nsamp=len(wavef2) #Length of the waveform after setting t1
    print('3 - csv file trimmed OK')
    
    
    #Filtering out Nan's
    wavef3=wavef2.dropna(subset=['Time']) #Filtering out Nan's
    print('4 - Filtered out Nan values - OK')
    x=wavef3['Time']#Unit labels
    if ChannelA_units == '(V)':
        y=wavef3['Channel A'] #If Amplitude is in V
        print('5 - Amp units in V - OK')
    elif ChannelA_units == '(mV)':
       y=wavef3['Channel A']*1e-3 #If Amplitude is in mV
       print('5 - Amp units corrected from mV to V - OK')
    else:
        print('Channel A unit unknown')
 
    #Print Waveform info on terminal screen
    print('----------------')
    print('Waveform Statistics')
    print(' ')
    print('Unfiltered')
    print("Max Amp : %8.4f" % (np.max(y)))
    print("Min Amp : %8.4f" % (np.min(y)))
    print("Mean Amp : %8.4f" % (np.mean(y)))
    
    #Print Waveform Info to a Report log file
    logfname=outfnamehead+'.log'
    logfile=open(logfname,'a+')
    print('################',file=logfile)
    print('Python codes for analyzing Picoscope data for Rock Physics',file=logfile)
    print('Single Waveform Processing',file=logfile)
    print('Contact: Prof. Marco Ceia (UENF/CCT/LENEP) - marco@lenep.uenf.br',file=logfile)
    print(' ',file=logfile)
    print('LOG REPORT',file=logfile)
    print('----------------',file=logfile)
    now = datetime.now()
    print("Date and Time =", now,file=logfile)
    print('Input filename                      : '+loc,file=logfile)
    print('Rock Sample ID                      : '+samplid,file=logfile)
    print("Number of samples (unfilt waveform) : %8.0f" % (nsamp),file=logfile)
    print('Selection Initial time - t1 (microsec): '+str(t1),file=logfile)
    print('----------------',file=logfile)
    print('Waveform Statistics',file=logfile)
    print(' ',file=logfile)
    print('Unfiltered',file=logfile)
    print('Amp Units : '+ChannelA_units,file=logfile)
    print("Max Amp  : %8.4f" % (np.max(y)),file=logfile)
    print("Min Amp  : %8.4f" % (np.min(y)),file=logfile)
    print("Mean Amp : %8.4f" % (np.mean(y)),file=logfile)
    logfile.close()
    return wavef,wavef2,wavef3,x,y,Time_units,ChannelA_units,lfile,tmax,tmin,nsamp

#-----------------------------------------------------------------------------   


def openfiltwave():    
    #Read filtered Waveform file (*.csv)
    global csvname,outfnamehead,loc,samplid,logfile, logfname
    csvname = askopenfilename(initialdir=idir,
                           filetypes =(("Filtered Waveform Files", "*_filtd.csv"),("All Files","*.*")),
                           title = "Choose a file."
                           )
    if not csvname:
        return
    
    global wavef, wavef2,wavef3,x,y,csvfile,Time_units,ChannelA_units,lfile,tmax,tmin,nsamp
    csvfile=pd.read_csv(csvname, delimiter=';') #Read whole csv file for getting the units
    Time_units='us' #Time Units
    ChannelA_units='V' #Amplitude Units
    lfile=len(csvfile) #Length of Input file
    wavef=pd.read_csv(csvname, delimiter=';') #Read csv file but skipping the unit row
    tmax=wavef.Time.max()
    tmin=wavef.Time.min()
    outfnamehead=csvname[0:(len(csvname)-4)]
    loc=csvname
#    lidir=len(idir) #Length of input folder
#    lloc=len(loc)   #Length of input file
#    samplid=loc[(lidir+1):(lloc-4)]
    ffname=os.path.basename(csvname) #Obtaining the file name
    extsep=np.char.find(ffname,'.') #Obtaining the position of the dot separator from the extension
    samplid=ffname[0:extsep] #Excluding the extension from the filename.
    
    print('2 - csv file read OK')
#    icontrol=1
    wavef2=wavef.where(wavef['Time'] > t1) #Samples lower than t1 will be read as Nan's
    nsamp=len(wavef2) #Length of the waveform after setting t1
    print('3 - csv file trimmed OK')
    
    
    #Filtering out Nan's
    wavef3=wavef2.dropna(subset=['Time']) #Filtering out Nan's
    print('4 - Filtered out Nan values - OK')
    x=wavef3['Time']#Unit labels
    if ChannelA_units == 'V':
        y=wavef3['Channel A'] #If Amplitude is in V
        print('5 - Amp units in V - OK')
    elif ChannelA_units == 'mV':
        y=wavef3['Channel A']*1e-3 #If Amplitude is in mV
        print('5 - Amp units corrected from mV to V - OK')
    else:
        print('Channel A unit unknown')
 
    #Print Waveform info on terminal screen
    print('----------------')
    print('Waveform Statistics')
    print(' ')
    print('Filtered')
    print("Max Amp : %8.4f" % (np.max(y)))
    print("Min Amp : %8.4f" % (np.min(y)))
    print("Mean Amp : %8.4f" % (np.mean(y)))
    
    #Print Waveform Info to a Report log file
    logfname=outfnamehead+'.log'
    logfile=open(logfname,'a+')
    print('################',file=logfile)
    print('Python codes for analyzing Picoscope data for Rock Physics',file=logfile)
    print('Single Waveform Processing',file=logfile)
    print('Author: Prof. Marco Ceia (UENF/CCT/LENEP) - marco@lenep.uenf.br',file=logfile)
    print(' ',file=logfile)
    print('LOG REPORT',file=logfile)
    print('----------------',file=logfile)
    now = datetime.now()
    print("Date and Time =", now,file=logfile)
    print('Input filename                      : '+loc,file=logfile)
    print('Rock Sample ID                      : '+samplid,file=logfile)
    print("Number of samples (filt waveform) : %8.0f" % (nsamp),file=logfile)
    print('Selection Initial time - t1 (microsec): '+str(t1),file=logfile)
    print('----------------',file=logfile)
    print('Waveform Statistics',file=logfile)
    print(' ',file=logfile)
    print('Filtered',file=logfile)
    print('Amp Units : '+ChannelA_units,file=logfile)
    print("Max Amp  : %8.4f" % (np.max(y)),file=logfile)
    print("Min Amp  : %8.4f" % (np.min(y)),file=logfile)
    print("Mean Amp : %8.4f" % (np.mean(y)),file=logfile)
    logfile.close()
    return wavef,wavef2,wavef3,x,y,Time_units,ChannelA_units,lfile,tmax,tmin,nsamp


#-----------------------------------------------------------------------------
def plotwavef(wavefname,fname): 
    #Plot  - Waveform 
    global icontrol, Tline, maxvv, minvv
    fig=plt.figure(2,figsize=(hgraph,vgraph))
    ax = fig.add_subplot(111)
    ax.plot(wavefname['Time'],wavefname['Channel A'],'k-')
    maxv=wavefname['Channel A'].max()
    minv=wavefname['Channel A'].min()
    maxvv=maxv
    minvv=minv
    print('maxvv ='+str(maxvv))
    Tline = draggable_lines(ax, "v",0.5,maxvv,minvv)
    plt.xlabel('Time ($\mu$s)', fontsize=fts)
    plt.ylabel('Amplitude ('+ChannelA_units+')', fontsize=fts)
    plt.xticks(fontsize=ticksize)
    plt.yticks(fontsize=ticksize)
    plt.suptitle(samplid)
    ax.grid()
    #return

#-----------------------------------------------------------------------------
def specfreq(wavefname):
    #Spectral Analysis
    
    #Calculating unfiltered waveform parameters
    global ns,dt,fs,nyq,f1,Pxx_spec,pow2
    ns=len(y) #Number of samples after filtering out Nan's
    tt=x*1e-6 #Time Vector
    dt=tt[tt.index[2]]-tt[tt.index[1]] #Sampling Interval   
    fs=(1/dt) #Sampling Frequency
    nyq=0.5*fs #Nyquist frequency 
    
    #Calculating Freq Spectra using Welch method 
    #f1, Pxx_spec = signal.welch(y,fs,wtype, scaling='spectrum')
    f1, Pxx_spec = signal.welch(y,fs,wtype, scaling='density',nperseg=len(y),average='mean',detrend=False,return_onesided=True)
    # power spectrum, via scipy welch. 'boxcar' means no window, nperseg=len(y) so that fft computed on the whole signal.
    #freq2,power2=scipy.signal.welch(y, fs=len(y)/framelength,window='boxcar',nperseg=len(y),scaling='spectrum', axis=-1, average='mean')

    #Calculating Freq Spectra using FFTpack 
    sig_fft = fftpack.fft(y)
    scaf=1e-3 #Scaling factor observed from the experimental data for matching both PSD curves
    power = (scaf)*((np.abs(sig_fft))**2)/fs #Scaling Factor for DENSITY
          
    # The corresponding frequencies
    sample_freq = fftpack.fftfreq(np.size(y), d=dt)
    
    # Find the peak frequency: we can focus on only the positive frequencies
    pos_mask = np.where(sample_freq > 0)
    freqs = sample_freq[pos_mask]

    pow2=power[pos_mask]
#    peak_freq = freqs[power[pos_mask].argmax()]
    
   
    #Display Info - Spec Unfiltered
    print('----------------')
    print('Spectral Statistics')
    print(' ')
    print('Unfiltered')
    print("Number of samples : %8.0f" % (ns))
    print("dt : %3.8f" % (dt))
    print("fs (Hz): %8.3f" % (fs))
    print("Nyquist Freq (Hz): %8.3f" % (nyq))
    spmaxid_uf=np.argmax((Pxx_spec)) #Index of max freq spectra amplitude - Unfilt
    fpeak_uf=f1[spmaxid_uf] #Peak Freq (spectral) - Unfilt
    print("Peak Frequency (Hz) : %8.3e" % (fpeak_uf))
    print(' ')
    print("Scipy FFT.pack - Spec amp size: "+str(np.size(pow2)))
    print("Scipy Welch - Spec amp size: "+str(np.size(Pxx_spec)))
    #Plots
    #PLot PSD using Welch Method
    plt.figure(num='Power Spectrum Density',figsize=(hgraph,vgraph))
    #plt.semilogx(f1, np.sqrt(Pxx_spec))
    plt.semilogx(f1, (Pxx_spec),'r:', label='Scipy-Welch Method')
    plt.semilogx(freqs, pow2,'b-',label='Scipy-FFTPack Method')
    plt.legend(loc='best')
    plt.xlabel('Frequency (Hz)',fontsize=fts)
    plt.ylabel('Power Spectral Density (V²/Hz) - Unfiltered', fontsize=fts2)
    plt.title('Power spectrum - Unfiltered - '+samplid)
    plt.xticks(fontsize=ticksize)
    plt.yticks(fontsize=ticksize)
    
       
    #Write Info to log file - Spec Unfiltered
    logfile=open(logfname,'a+')
    print("Sampling Interval  - dt (microsec)  : %8.2f" % (dt),file=logfile)
    print("Sampling Frequency - fs (Hz)        : %8.3f" % (fs),file=logfile)
    print("Nyquist Freq (Hz)                   : %8.3f" % (nyq),file=logfile)
    print("Peak Frequency (Hz)                 : %8.3e" % (fpeak_uf),file=logfile)    
    print(' ',file=logfile)
    logfile.close()
    return ns,dt,fs,nyq,f1,Pxx_spec
#-----------------------------------------------------------------------------

def filtset(wavefname,amps,freqs,specs):
    global fc1,fc2,f2,y_filtd,Pxf_spec
    
    specfreq(wavefname)
        
    class MyDialog(tk.simpledialog.Dialog):
    #class MyDialog(window):

        def body(self, master=None):
            super().body(master)

            self.master = master
        
            Label(master, text="Enter fc1 in Hz:").grid(row=0)
            Label(master, text="Enter fc2 in Hz:").grid(row=1)
            self.e1 = Entry(master)
            self.e2 = Entry(master)
            
            self.e1.grid(row=0, column=1)
            self.e2.grid(row=1, column=1)
            #return self.e1 # initial focus
    
        def apply(self):
            global ffc1,ffc2
            ffc1 = self.e1.get()
            ffc2 = self.e2.get()
            print('OK')
            self.result = ffc1, ffc2
                        
    root1 = tk.Tk()
    root1.title("Setting Bandpass frequency cutoffs")
    root1.withdraw()
    d = MyDialog(root1)
    root1.destroy()

    #Assigning the cutoff freqs
    fc1=float(ffc1) #Low freq cutoff - Band lower limit
    fc2=float(ffc2) #High freq cutoff - Band Higher limit

    print('Low cutoff freq  : '+str(fc1))
    print('High cutoff freq : '+str(fc2))

    fcut=[fc1,fc2] #Filter parameters setting
#    #Ask cutoff frequencies for bandapass filtering
#    fc1 = askfloat('Set lowest cutoff frequency','Enter fc1 in Hz')
#    fc2 = askfloat('Set highest cutoff frequency','Enter fc2 in Hz')
#    print('Low cutoff freq  : '+str(fc1))
#    print('High cutoff freq : '+str(fc2))
#    fcut=[fc1,fc2] #Filter parameters setting
    Wb=[fcut[0]/nyq,fcut[1]/nyq] #Filter parameters for bandpass filtering
    print('Wb :')
    print(Wb)
    b, a = signal.butter(1, Wb, 'band') #Calculating parameters for band-pass filter
    
    #Filtering the waveform
    y_filtd = signal.filtfilt(b, a, amps) 
    #Frequency spectrum of the filtered waveform
    f2, Pxf_spec = signal.welch(y_filtd,fs,wtype,  scaling='density',nperseg=len(y_filtd),average='mean',detrend=False,return_onesided=True)
    #f1, Pxx_spec = signal.welch(y,fs,'boxcar', scaling='density',nperseg=len(y),average='mean',detrend=False,return_onesided=True)

    #Setting limits
    apmin_uf=np.min(amps)
    apmin_f=np.min(y_filtd)
    Amp_min=np.min([apmin_uf,apmin_f]) #Setting Amplitude axis min value
    apmax_uf=np.max(amps)
    apmax_f=np.max(y_filtd)
    Amp_max=np.max([apmax_uf,apmax_f]) #Setting Amplitude axis max value
    
#    T_min=0 #Time limits to be used only for displaying an specific time range
#    T_max=50
    Spec_min=0
    spmax_uf=np.max((Pxx_spec))
    spmax_f=np.max((Pxf_spec))
    Spec_max=np.max([spmax_uf,spmax_f]) 
    spmaxid_f=np.argmax((Pxf_spec))  #Index of max freq spectra amplitude - filt
    fpeak_f=f2[spmaxid_f]  #Peak Freq (spectral) - filt
#    icontrol=1
    
    #Display Info - Spec Unfiltered
    print('----------------')
    print('Waveform Statistics')
    print(' ')
    print('Filtered')
    print("Max Amp : %8.4f" % (np.max(y_filtd)))
    print("Min Amp : %8.4f" % (np.min(y_filtd)))
    print("Mean Amp : %8.4f" % (np.mean(y_filtd)))
    print("Peak Frequency (Hz) : %8.3e" % (fpeak_f))
    print('----------------')

    #Write Info to log file - Wavef filtered
    logfile=open(logfname,'a+')
    print('----------------',file=logfile)
    print('Filtered',file=logfile)
    print(' ',file=logfile)
    print('Amp Units : (V)',file=logfile)
    print("Max Amp : %8.4f" % (np.max(y_filtd)),file=logfile)
    print("Min Amp : %8.4f" % (np.min(y_filtd)),file=logfile)
    print("Mean Amp : %8.4f" % (np.mean(y_filtd)),file=logfile)
    
    #Write Info to log file - Spec filtered
    print("Peak Frequency (Hz) : %8.3e" % (fpeak_f),file=logfile)
    print("Low Cutoff Frequency  (Hz) : %8.0f" % (fcut[0]),file=logfile)
    print("High Cutoff Frequency (Hz) : %8.0f" % (fcut[1]),file=logfile)
    print('Window type                : '+wtype,file=logfile)
    print("Number of samples (filt waveform)   : %8.0f" % (ns),file=logfile)                    
    print(' ',file=logfile)
    logfile.close()

    #Graphics - Comparison betwenn Unfiltered and Filtered waveforms and spectra
    fax = plt.figure(num='Waveform Comparison Filtd x Unfiltd - Butterworth Filter',figsize=(20,10))
    ax1=fax.add_subplot(211)
    ax1.plot(wavefname, amps, 'b-',label='Original signal')
    ax1.plot(wavefname, y_filtd, 'r-',label='FIltered signal')
    plt.ylabel('Amplitude (V)',fontsize=fts2)
    plt.xlabel('Time ($\mu$s)',fontsize=fts2)
    plt.title('Original (Unfiltered) Data',fontsize=fts2)
    plt.legend(loc='best')
    plt.grid()
#    plt.xlim(T_min,T_max) 
#    plt.ylim(Amp_min,Amp_max) 
    plt.xticks(fontsize=fts2)
    plt.yticks(fontsize=fts2)
    
   
    ax2=fax.add_subplot(212)
    ax2.semilogx(f1, (Pxx_spec), 'b-',label='Original signal')
    ax2.semilogx(f2, (Pxf_spec), 'r-',label='FIltered signal')
    plt.xlabel('Frequency (Hz)',fontsize=fts2)
    plt.ylabel('Power Spectral Density (V²/Hz) - Unfiltered',fontsize=fts2)
    plt.title('Power spectrum - Unfiltered',fontsize=fts2)
    plt.legend(loc='best')
    #    plt.xlim(1e4,1e7) 
    #    plt.ylim(Spec_min,Spec_max) 
    plt.xticks(fontsize=fts2)
    plt.yticks(fontsize=fts2)
       
    fax.suptitle(samplid)
    fax.show()
    
    return fc1,fc2

#-----------------------------------------------------------------------------
def freqgain(wavefname,amps):
    #Spectral filtering with freq gain option
    global fc1,fc2,gain, freqs, pow2, filtered_sig, d

    sig=amps
    tt=wavefname*1e-6
    
    ns1=len(wavefname) #Number of samples after filtering out Nan's
    #dt1=sig[sig.index[2]]-sig[sig.index[1]] #Sampling Interval
    dt1=tt[tt.index[2]]-tt[tt.index[1]] #Sampling Interval    
    fs=(1/dt1)*1e6 #Sampling Frequency
    
    sig_fft = fftpack.fft(sig)
    scaf=1e-3 #Scaling factor observed from the experimental data for matching both PSD curves
    power = (scaf)*((np.abs(sig_fft))**2)/fs #Scaling Factor for DENSITY
          
    #power = np.abs(sig_fft)
    
    # The corresponding frequencies
    sample_freq = fftpack.fftfreq(np.size(sig), d=dt1)
    #ff=np.where(sample_freq>0,sample_freq,sample_freq)
    #ssig=np.where(sample_freq>0,sample_freq,power)
    

    
    # Find the peak frequency: we can focus on only the positive frequencies
    pos_mask = np.where(sample_freq > 0)
    freqs = sample_freq[pos_mask]
    pow2=power[pos_mask]
    peak_freq = freqs[power[pos_mask].argmax()]
    
    # Plot the FFT power
    plt.figure(num='PSD FFTPack - Unfiltered',figsize=(hgraph,vgraph))
    plt.semilogx(freqs, pow2)
    plt.xlabel('Frequency [Hz]')
    plt.ylabel('Power Spectral Density - (V²/Hz)')
    
    #Ask cutoff frequencies for bandapass filtering

    class MyDialog(tk.simpledialog.Dialog):
    #class MyDialog(window):

        def body(self, master=None):
            super().body(master)

            self.master = master
        
            Label(master, text="Enter fc1 in Hz:").grid(row=0)
            Label(master, text="Enter fc2 in Hz:").grid(row=1)
            Label(master, text="Enter the gain for the selected freq range: ").grid(row=2)
            self.e1 = Entry(master)
            self.e2 = Entry(master)
            self.e3 = Entry(master)
            
            self.e1.grid(row=0, column=1)
            self.e2.grid(row=1, column=1)
            self.e3.grid(row=2, column=1)
            #return self.e1 # initial focus
    
        def apply(self):
            global ffc1,ffc2, fgain
            ffc1 = self.e1.get()
            ffc2 = self.e2.get()
            fgain = self.e3.get()
            print('OK')
            self.result = ffc1, ffc2, fgain
                        
    root1 = tk.Tk()
    root1.title("Setting Bandpass frequency cutoffs")
    root1.withdraw()
    d = MyDialog(root1)
    root1.destroy()

    #Assigning the cutoff freqs
    fc1=float(ffc1) #Low freq cutoff - Band lower limit
    fc2=float(ffc2) #High freq cutoff - Band Higher limit
    gain=float(fgain) 
    print('Low cutoff freq  : '+str(fc1))
    print('High cutoff freq : '+str(fc2))
    print('Freq Gain : '+str(gain))
    fcut=[fc1,fc2] #Filter parameters setting
    mask_freqs = sample_freq[np.where((sample_freq >= fc1) & (sample_freq <= fc2))]
        
    #Bandpass filtering - FFT amplitude values are zeroed outside of the fc1<f<fc2 range
    filtdata_freq_fft = sig_fft.copy()
    mu=(fc1+fc2)/2 #Mean frequency - for Gaussian distribution
    cvar1=(mask_freqs-mu)**2
    sigma2=(np.sum(cvar1)/(len(mask_freqs))) #Variance - for Gaussian distribution
    sigma=np.sqrt(sigma2) #Variance - for Gaussian distribution
    gterm1=(mask_freqs-mu)/(sigma)
    gterm2=-(1/2)*(gterm1**2)
    gauss_dist=(1/(sigma*np.sqrt(2*np.pi)))*np.exp(gterm2)
    #gaina=np.ones(nfft)*gain
    gaina=(gain*1e6)*gauss_dist
    plt.figure(3)
    plt.plot(mask_freqs,gaina,'o')
    plt.xlabel('Frequency (Hz)', fontsize=fts2)
    plt.ylabel('Gain', fontsize=fts2)
        
#    print(len(freqs))

    print('mu = '+str(mu))
    print('var² ='+str(sigma))
    print('Length gain vector ='+str(len(gaina)))
    print('Length Mask freqs ='+str(len(mask_freqs)))
    print('Length sample freqs ='+str(len(sample_freq)))

    filt_freq=filtdata_freq_fft
    print('Length filt freqs ='+str(len(filt_freq)))    
    filt_freq[np.where((sample_freq >= fc1) & (sample_freq <= fc2))]=(filtdata_freq_fft[np.where((sample_freq >= fc1) & (sample_freq <= fc2))])*gaina
    filtered_sig = fftpack.ifft(filt_freq)
#    pow3=np.abs(filt_freq[pos_mask])
#    filt_freq=filtdata_freq_fft
#    print('Length filt freqs ='+str(len(filt_freq)))    
#    #filt_freq[np.where((sample_freq >= fc1) & (sample_freq <= fc2))]=(filtdata_freq_fft[np.where((sample_freq >= fc1) & (sample_freq <= fc2))])*gaina
#    filtered_sig = fftpack.ifft(filt_freq)
    scaf=1e-3 #Scaling factor observed from the experimental data for matching both PSD curves
    pow3=(scaf)*(np.abs(filt_freq[pos_mask])**2)/fs
    
    #Graphics - Comparison betwenn Unfiltered and Filtered waveforms and spectra
    fax = plt.figure(num='Waveform Comparison Filtd x Unfiltd - Boxcar with Gaussian Gain',figsize=(20,10))
    ax1=fax.add_subplot(211)
    ax1.plot(tt*1e6, sig, 'b-',label='Original signal')
    ax1.plot(tt*1e6, filtered_sig.real, 'r-',label='FIltered signal')
    plt.ylabel('Amplitude (V)', fontsize=fts2)
    plt.xlabel('Time ($\mu$s)', fontsize=fts2)
    plt.title('Original (Unfiltered) Data', fontsize=fts2)
    plt.legend(loc='best')
    plt.grid()
#    plt.xlim(T_min,T_max) 
#    plt.ylim(Amp_min,Amp_max) 
    plt.xticks(fontsize=fts2)
    plt.yticks(fontsize=fts2)
    
   
    ax2=fax.add_subplot(212)
    ax2.semilogx(freqs, pow2, 'b-',label='Original signal')
    ax2.semilogx(freqs,pow3, 'r-',label='FIltered signal')
    plt.xlabel('Frequency (Hz)', fontsize=fts2)
    plt.ylabel('Power Spectral Density (V²/Hz) - Unfiltered', fontsize=fts2)
    plt.title('Power spectrum - Unfiltered', fontsize=fts2)
    plt.legend(loc='best')
    #    plt.xlim(1e4,1e7) 
    #    plt.ylim(Spec_min,Spec_max) 
    plt.xticks(fontsize=fts2)
    plt.yticks(fontsize=fts2)
       
    fax.suptitle(samplid)
    fax.show()
    

#    
# #
#    #Write Info to log file - Wavef filtered
#    logfile=open(logfname,'a+')
#    print('----------------',file=logfile)
#    print('Filtered',file=logfile)
#    print(' ',file=logfile)
#    print('Amp Units : (V)',file=logfile)
#    print("Max Amp : %8.4f" % (np.max(y_filtd)),file=logfile)
#    print("Min Amp : %8.4f" % (np.min(y_filtd)),file=logfile)
#    print("Mean Amp : %8.4f" % (np.mean(y_filtd)),file=logfile)
#    
#    #Write Info to log file - Spec filtered
#    print("Peak Frequency (Hz) : %8.3e" % (fpeak_f),file=logfile)
#    print("Low Cutoff Frequency  (Hz) : %8.0f" % (fcut[0]),file=logfile)
#    print("High Cutoff Frequency (Hz) : %8.0f" % (fcut[1]),file=logfile)
#    print('Window type                : '+wtype,file=logfile)
#    print("Number of samples (filt waveform)   : %8.0f" % (ns),file=logfile)                    
#    print(' ',file=logfile)
#    logfile.close()
#
#    fax = plt.figure(figsize=(20,10))
#    ax1=fax.add_subplot(221)
#    ax1.plot(wavefname, amps, 'k')
#    plt.ylabel('Amplitude (V)')
#    plt.xlabel('Time ($\mu$s)')
#    plt.title('Original (Unfiltered) Data')
#    plt.xlim(T_min,T_max) 
#    plt.ylim(Amp_min,Amp_max) 
#    plt.xticks(fontsize=fts2)
#    plt.yticks(fontsize=fts2)
#    
#    ax2=fax.add_subplot(222)
#    ax2.plot(wavefname, y_filtd, 'k')
#    plt.ylabel('Amplitude (V)')
#    plt.xlabel('Time ($\mu$s)')
#    plt.title('Filtered Data')
#    plt.xlim(T_min,T_max) 
#    plt.ylim(Amp_min,Amp_max) 
#    plt.xticks(fontsize=fts2)
#    plt.yticks(fontsize=fts2)
#    
#    ax3=fax.add_subplot(223)
#    ax3.semilogx(f1, np.sqrt(Pxx_spec))
#    plt.xlabel('Frequency (Hz)')
#    plt.ylabel('Linear spectrum (V RMS) - Unfiltered')
#    plt.title('Power spectrum - Unfiltered')
#    plt.xlim(1e4,1e7) 
#    plt.ylim(Spec_min,Spec_max) 
#    plt.xticks(fontsize=fts2)
#    plt.yticks(fontsize=fts2)
#    
#    ax4=fax.add_subplot(224)
#    ax4.semilogx(f2, np.sqrt(Pxf_spec))
#    plt.xlabel('Frequency (Hz)')
#    plt.ylabel('Linear spectrum (V RMS) - Filtered')
#    plt.title('Power spectrum - Filtered')
#    plt.xlim(1e4,1e7) 
#    plt.ylim(Spec_min,Spec_max) 
#    plt.xticks(fontsize=fts2)
#    plt.yticks(fontsize=fts2)
#    
#    fax.suptitle(samplid)
#    fax.show()
    return fc1,fc2,gain, freqs, pow2, filtered_sig


#-----------------------------------------------------------------------------
def freqgain2(wavefname,amps):
    #Spectral filtering with freq gain option
    global fc1,fc2,gain, freqs, pow2, filtered_sig, d

    sig=amps
    tt=wavefname*1e-6
    
    ns1=len(wavefname) #Number of samples after filtering out Nan's
    #dt1=sig[sig.index[2]]-sig[sig.index[1]] #Sampling Interval
    dt1=tt[tt.index[2]]-tt[tt.index[1]] #Sampling Interval    
    fs=(1/dt1)
    #fs=(1/dt1)*1e6 #Sampling Frequency
    
    sig_fft = fftpack.fft(sig)
    #scaf=1
    scaf=1e-3 #Scaling factor observed from the experimental data for matching both PSD curves
    power = (scaf)*((np.abs(sig_fft))**2)/fs #Scaling Factor for DENSITY
          
    #power = np.abs(sig_fft)
    
    # The corresponding frequencies
    sample_freq = fftpack.fftfreq(np.size(sig), d=dt1)
    #ff=np.where(sample_freq>0,sample_freq,sample_freq)
    #ssig=np.where(sample_freq>0,sample_freq,power)
    

    
    # Find the peak frequency: we can focus on only the positive frequencies
    pos_mask = np.where(sample_freq > 0)
    freqs = sample_freq[pos_mask]
    pow2=power[pos_mask]
    peak_freq = freqs[power[pos_mask].argmax()]
    
    # Plot the FFT power
    plt.figure(num='PSD FFTPack - Unfiltered',figsize=(hgraph,vgraph))
    plt.semilogx(freqs, pow2)
    plt.xlabel('Frequency [Hz]')
    plt.ylabel('Power Spectral Density - (V²/Hz)')
    
    #Ask cutoff frequencies for bandapass filtering

    class MyDialog(tk.simpledialog.Dialog):
    #class MyDialog(window):

        def body(self, master=None):
            super().body(master)

            self.master = master
        
            Label(master, text="Enter fc1 in Hz:").grid(row=0)
            Label(master, text="Enter fc2 in Hz:").grid(row=1)
            Label(master, text="Enter the Low Freq gain (f<fc1): ").grid(row=2)
            Label(master, text="Enter the gain for the selected freq range (fc1<=f<=fc2): ").grid(row=3)
            Label(master, text="Enter the High Freq gain (f>fc2): ").grid(row=4)
                       
            self.e1 = Entry(master)
            self.e2 = Entry(master)
            self.e3 = Entry(master)
            self.e4 = Entry(master)
            self.e5 = Entry(master)
            
            self.e1.grid(row=0, column=1)
            self.e2.grid(row=1, column=1)
            self.e3.grid(row=2, column=1)
            self.e4.grid(row=3, column=1)
            self.e5.grid(row=4, column=1)
            #return self.e1 # initial focus
    
        def apply(self):
            global ffc1,ffc2, flgain,fbgain,fhgain
            ffc1 = self.e1.get()
            ffc2 = self.e2.get()
            flgain = self.e3.get()
            fbgain = self.e4.get()
            fhgain = self.e5.get()
            #print('OK')
            self.result = ffc1, ffc2, flgain,fbgain,fhgain
                        
    root1 = tk.Tk()
    root1.title("Setting Bandpass frequency cutoffs")
    root1.withdraw()
    d = MyDialog(root1)
    #print(d.result)
    root1.destroy()
    
    fc1=float(ffc1) #Converting Entry from str to float
    fc2=float(ffc2)
    lgain=float(flgain)
    bgain=float(fbgain)
    hgain=float(fhgain)
    
    print('Low cutoff freq  : '+str(fc1))
    print('High cutoff freq : '+str(fc2))
    print('Low Freq Gain : '+str(lgain))
    print('Band Freq Gain : '+str(bgain))
    print('High Freq Gain : '+str(hgain))
    
    fcut=[fc1,fc2] #Filter parameters setting
    mask_freqs_band = np.where((sample_freq >= fc1) & (sample_freq <= fc2))
    mask_freqs_low = np.where((sample_freq < fc1)) 
    mask_freqs_high = np.where((sample_freq > fc2))
    #Bandpass filtering - FFT amplitude values are zeroed outside of the fc1<f<fc2 range
    filtdata_freq_fft = sig_fft.copy()
    nfft=len(filtdata_freq_fft)

    filtdata_freq_fft[mask_freqs_low]=filtdata_freq_fft[mask_freqs_low]*lgain
    filtdata_freq_fft[mask_freqs_band]=filtdata_freq_fft[mask_freqs_band]*bgain
    filtdata_freq_fft[mask_freqs_high]=filtdata_freq_fft[mask_freqs_high]*hgain
 
    filt_freq=filtdata_freq_fft
    print('Length filt freqs ='+str(len(filt_freq)))    
    #filt_freq[np.where((sample_freq >= fc1) & (sample_freq <= fc2))]=(filtdata_freq_fft[np.where((sample_freq >= fc1) & (sample_freq <= fc2))])*gaina
    filtered_sig = fftpack.ifft(filt_freq)
    scaf=1e-3 #Scaling factor observed from the experimental data for matching both PSD curves
    pow3=(scaf)*(np.abs(filt_freq[pos_mask])**2)/fs
    #pow3=np.abs(filt_freq[pos_mask])
    
    #sig_fft = fftpack.fft(sig)
    #scaf=1
    
    #power = (scaf)*((np.abs(sig_fft))**2)/fs #Scaling Factor for DENSITY
    
    #Graphics - Comparison betwenn Unfiltered and Filtered waveforms and spectra
    fax = plt.figure(num='Waveform Comparison Filtd x Unfiltd - Boxcar with 3-Band Gain',figsize=(20,10))
    ax1=fax.add_subplot(211)
    ax1.plot(tt*1e6, sig, 'b-',label='Original signal')
    ax1.plot(tt*1e6, filtered_sig.real, 'r-',label='FIltered signal')
    plt.ylabel('Amplitude (V)', fontsize=fts2)
    plt.xlabel('Time ($\mu$s)', fontsize=fts2)
    plt.title('Original (Unfiltered) Data', fontsize=fts2)
    plt.legend(loc='best')
    plt.grid()
#    plt.xlim(T_min,T_max) 
#    plt.ylim(Amp_min,Amp_max) 
    plt.xticks(fontsize=fts2)
    plt.yticks(fontsize=fts2)
    
   
    ax2=fax.add_subplot(212)
    ax2.semilogx(freqs, pow2, 'b-',label='Original signal')
    ax2.semilogx(freqs,pow3, 'r-',label='FIltered signal')
    plt.xlabel('Frequency (Hz)', fontsize=fts2)
    plt.ylabel('Power Spectral Density (V²/Hz) - Unfiltered', fontsize=fts2)
    plt.title('Power spectrum - Unfiltered', fontsize=fts2)
    plt.legend(loc='best')
    #    plt.xlim(1e4,1e7) 
    #    plt.ylim(Spec_min,Spec_max) 
    plt.xticks(fontsize=fts2)
    plt.yticks(fontsize=fts2)
       
    fax.suptitle(samplid)
    fax.show()
#    
    return

#-----------------------------------------------------------------------------
def savewavef(wavefname,amps):
    #Saving the filtered waveform
    xout=pd.Series.reset_index(wavefname, drop='True') #Reseting Index of x-vector (panda Series)
    yfiltd=pd.Series(amps) #Transforming y_filtd array to pandas Series
    yout=pd.Series.reset_index(yfiltd, drop='True') #Reseting Index of y-vector (panda Series)
    df=pd.concat([xout,yout], axis=1, ignore_index=False) #Joining both series in a dataframe
    df.rename(columns={0:'Channel A'}, inplace=True) #Renaming column name (0 -> Amplitude)

    outfile=outfnamehead+'_filtd.csv' #Setting output filename  
    df.to_csv(outfile, index=False, header=True, sep=';') #Writing dataframe to a CSV file
    print('Filtered waveform saved to: '+outfile)
    print('################')
          
    logfile=open(logfname,'a+')
    print('----------------',file=logfile)
    print('Filtered waveform saved to: '+outfile,file=logfile)
    logfile.close()
    icontrol=1
    return
#-----------------------------------------------------------------------------
def exitwavespy():
    print('Finish WavesPY')
    root.destroy()
    return

def habout():
    root2=tk.Tk()
    root2.title('About')
    text = tk.Text(root2, height=8,width=35)
    text.pack()
    text.insert(tk.END, 'WavesPY -   Waveform Processing\n'
                          '#############################\n'
                          '           UENF              \n'
                          '     CCT/LENEP -GMFPE        \n'                          
                          'Contact: Prof. Marco Ceia    \n'
                          '   (marco@lenep.uenf.br)     \n'
                          '   Version 1.2  Jun 2020     \n'
                          '#############################\n')
#    root2.withdraw()
#    root2.destroy()
    return

#    root1 = tk.Tk()
#    root1.title("Setting Bandpass frequency cutoffs")
#    root1.withdraw()
#    d = MyDialog(root1)
#    #print(d.result)
#    root1.destroy()
#------------------------------------------------------
def dualwave(wavein,samplid):    
    #Read signal file (*.csv)
    #global refname,routfnamehead,loc,refid,logfile, logfname
    refw = askopenfilename(initialdir=idir,
                           filetypes =(("Filtered Waveform Files", "*_filtd.csv"),("CSV Waveforn Files", "*.csv"),("All Files","*.*")),
                           title = "Choose a Reference Waveform."
                           )
    if not refw:
        return
    
    #global rwavef, rwavef2,rwavef,refw,xrefw,yrefw,reffile,rTime_units,rChannelA_units,lreffile,rtmax,rtmin,rnsamp
 
    refwave=pd.read_csv(refw, delimiter=';') 
    wavef=wavein
    xin=wavef['Time']
    yin=wavef['Channel A']
    #Reference waveform
    xrefw=refwave['Time']
    yrefw=refwave['Channel A']
    xmin=np.min(xin)
    xmax=np.max(xin)
    ymin=np.min(yin)
    ymax=np.max(yin)
    print('Length xin = '+ str(len(xin)))
    print('Length xrefw = '+ str(len(xrefw)))
    yl=np.max(np.abs(yin))
    yrefl=np.max(np.abs(yrefw))
    y_norm=yin/yl #Normalizing Amplitude values - Input waveform
    yrefw_norm=yrefw/yrefl #Normalizing Amplitude values - Ref waveform
    ref2=y_norm.mean() #Mean amplitude value (in V) - Used as a reference value.
    
    #Shift y-axis of waveforms
    iwin=200 #Investigation window - Number of rows to investigate
    #iwin=150 #Investigation window - Number of rows to investigate
    y_shift=np.mean(y_norm[0:iwin])
    yref_shift=np.mean(yrefw_norm[0:iwin])
    
    yy_norm=y_norm-y_shift
    yyrefw_norm=yrefw_norm-yref_shift
    
    #Plotting Figure
    fig, ax1 = plt.subplots()
    ax2 = ax1.twiny()
    
    ax1.grid()
    fig.subplots_adjust(bottom=0.25)
    
    
    ax2_pos = fig.add_axes([0.2, 0.1, 0.65, 0.03])
    ax1_pos = fig.add_axes([0.2, 0.05, 0.65, 0.03])
    
    ll=1
    print(ll)
    #Setting the sliders
    axcolor = 'lightgoldenrodyellow'
    s2 = Slider(ax2_pos, 'Input Waveform',np.min(xin), len(xin), valinit=1, facecolor=axcolor)
    s1 = Slider(ax1_pos, 'Ref Waveform',np.min(xrefw), len(xrefw),  valinit=1, facecolor=axcolor)
    
    #Figure updating figures
    def update1(v):
        pos = s1.val
        ax1.axis([pos,xmax+pos,-1,1])
        fig.canvas.draw_idle()
    
    def update2(v):
        pos = s2.val
        ax2.axis([pos,xmax+pos,-1,1])
        fig.canvas.draw_idle()
        
    s1.on_changed(update1)
    s2.on_changed(update2)
    
    lidir=len(idir) #Length of input folder
    lloc=len(refw)   #Length of input file
    refid=refw[(lidir+1):(lloc-4)]
    ax1.plot(xrefw, yyrefw_norm, 'b-',label='Reference Waveform :'+refid)
    ax2.plot(xin, yy_norm, 'k-',label='Input Waveform :'+samplid)
    ax2.legend(loc='upper left')
    ax1.legend(loc='upper right')
    ax1.set_title('Dual Waveform Analysis - (UENF/LENEP - GMFPE)',fontsize=fts)
    ax1.set_xlabel('Time ($\mu$s)',fontsize=fts)
    ax1.set_ylabel('Amplitude (V)',fontsize=fts)
    #fig.show()
    return
    

#-----------------------------------------------------------------------------
#Tkinter GUI initial definitions
#Main GUI
    
root = tk.Tk()
idir=os.getcwd()

logo = tk.PhotoImage(file="wavespy_logo.gif")
Title = root.title( "WavesPY")
root.iconbitmap('wavespy_logo.ico') #Use this command if want to load an ICO on the main window
#label = ttk.Label(root, text ="Python Waveform Analysis - UENF/LENEP",foreground="red",font=("Helvetica", 16))
label = ttk.Label(root, image=logo).pack(side="right")
#label.pack()
separator = Frame(height=2, bd=1, relief=SUNKEN)
separator.pack(fill=X, padx=5, pady=5)

#Menu Bar

menu = Menu(root)
root.config(menu=menu)

file = Menu(menu)
FFT = Menu(menu)
plot = Menu(menu)
help = Menu(menu)

file.add_command(label = 'Import Picoscope Files', command = OpenFile)
file.add_command(label = 'Open csv Files - Semi-colon Delimiter', command = lambda:opencsv())
file.add_command(label = 'Open csv Files - Comma Delimiter', command = lambda:opencsv2())
file.add_command(label = 'Open Filtered (csv) Files', command = lambda:openfiltwave())
file.add_command(label = 'Exit', command = exitwavespy)


FFT.add_command(label = 'Spectral Analysis', command = lambda:specfreq(x))
FFT.add_command(label = 'Butterworth Bandpass Filt', command = lambda:filtset(x,y,f1,Pxx_spec))
FFT.add_command(label = 'Boxcar Gaussian Gain', command = lambda:freqgain(x,y))
FFT.add_command(label = 'Boxcar 3-Band Gain', command = lambda:freqgain2(x,y))
FFT.add_command(label = 'Save Butterworth BP filtered file', command = lambda:savewavef(x,y_filtd))
FFT.add_command(label = 'Save Boxcar Gained file', command = lambda:savewavef(x,filtered_sig.real))

plot.add_command(label = 'Plot Waveform', command = lambda:plotwavef(wavef3,samplid))
plot.add_command(label = 'Dual Waveform Analysis', command = lambda:dualwave(wavef3,samplid))

help.add_command(label = 'About', command = habout)

menu.add_cascade(label = 'File', menu = file)
menu.add_cascade(label = 'Plot' , menu = plot)
menu.add_cascade(label = 'FFT' , menu = FFT)
menu.add_cascade(label = 'Help' , menu = help)


root.mainloop()


